import React from 'react';

const LoadingSpinner = () => {
  return <div className="spinner">Loading...</div>;
};

export default LoadingSpinner;
